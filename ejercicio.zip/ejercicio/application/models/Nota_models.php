<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Nota_models extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		
	}
	function getNota()
	{
		$query = $this->db->get('notas');
		return $query->result_array();
	}
	function getNotaById($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('notas');
		return $query->row();
	}
	function crearNota($data){
		$this->db->insert('notas',array('nota'=>$data['nota'], 'idUsuario'=>$data['idUsuario']));
	}
	function marcarNota($data){
		$this->db->insert('favoritas',array('idUsuario'=>$data['idUsuario'], 'idNota'=>$data['idNota'], 'favorita'=>$data['favorita']));
	}
	function getNotaFavoritas($id)
	{
		$this->db->where('idUsuario',$id);
		$query = $this->db->get('favoritas');
		return $query->result_array();
	}
	#function obtenerCursos(){
	#	$query = $this->db->get('videos');
	#	if($query->num_rows() > 0) return $query;
	#	else return false;
	#}
	#function obtenerCurso($id){
	#	$this->db->where('id',$id);
	#	$query = $this->db->get('videos');
	#	if($query->num_rows() > 0) return $query;
	#	else return false;
	#}
	#function actualizarCurso($id,$data){
	#	$datos = array(
	#		'nombre' => $data['nombre'],
	#		'cantidad' => $data['videos']
	#		);
	#	$this->db->where('id',$id);
	#	$query = $this->db->update('videos',$datos);
	#}
	#function eliminarCurso($id){
		//$this->db->delete('videos',array('id'=>$id));
	#	$query = "DELETE FROM videos WHERE id = $id";
	#	$this->db->query($query);
	#}
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class User_models extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		
	}
	function getUser()
	{
		$query = $this->db->get('usuarios');
		return $query->result_array();
	}
	function getUserById($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('usuarios');
		return $query->row();
	}


	#function crearCurso($data){
	#	$this->db->insert('videos',array('nombre'=>$data['nombre'], 'cantidad'=>$data['videos']));
	#}
	#function obtenerCursos(){
	#	$query = $this->db->get('videos');
	#	if($query->num_rows() > 0) return $query;
	#	else return false;
	#}
	#function obtenerCurso($id){
	#	$this->db->where('id',$id);
	#	$query = $this->db->get('videos');
	#	if($query->num_rows() > 0) return $query;
	#	else return false;
	#}
	#function actualizarCurso($id,$data){
	#	$datos = array(
	#		'nombre' => $data['nombre'],
	#		'cantidad' => $data['videos']
	#		);
	#	$this->db->where('id',$id);
	#	$query = $this->db->update('videos',$datos);
	#}
	#function eliminarCurso($id){
		//$this->db->delete('videos',array('id'=>$id));
	#	$query = "DELETE FROM videos WHERE id = $id";
	#	$this->db->query($query);
	#}
}